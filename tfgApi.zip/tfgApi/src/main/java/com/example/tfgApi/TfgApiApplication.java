package com.example.tfgApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TfgApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TfgApiApplication.class, args);
	}

}
