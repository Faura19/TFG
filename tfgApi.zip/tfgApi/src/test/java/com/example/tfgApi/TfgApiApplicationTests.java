package com.example.tfgApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TfgApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
